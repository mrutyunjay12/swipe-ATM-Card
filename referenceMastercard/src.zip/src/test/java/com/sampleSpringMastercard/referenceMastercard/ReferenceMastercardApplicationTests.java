package com.sampleSpringMastercard.referenceMastercard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReferenceMastercardApplicationTests {

	@Test
	void contextLoads() {
	}

}
